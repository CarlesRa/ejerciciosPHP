<?php 
  const ERROR_CONEXION_DB = -1;
  const ERROR_NOMBRE_EXISTE = -2;
  const OK = 1;
?>