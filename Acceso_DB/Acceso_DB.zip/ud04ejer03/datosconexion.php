<?php
  $db_host="localhost";
  $db_usuario="root";
  $db_contrasena="carles";
  $db_nombre="bdproductos";
?>