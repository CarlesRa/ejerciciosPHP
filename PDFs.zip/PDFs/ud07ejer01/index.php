<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Toys Shop</title>

  <link rel="stylesheet" href="./styles/style.css">
</head>
<body>
  <div class="container">

    <div class="logo">
      <h1>Bienvenido a Toy Shop</h1>
    </div>

    <div class="button">
      <form action="./ud07ejer01.php" method="get">
        <input type="submit" value="VENDER">
      </form>
    </div>
  </div>
  
</body>
</html>