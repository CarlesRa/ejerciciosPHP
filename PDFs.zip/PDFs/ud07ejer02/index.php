<?php 

  header("Location: cinelogin.php");

?>