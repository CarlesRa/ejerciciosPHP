<?php 

  # Códigos de error

  const ERROR_CONEXION_DB = -1;
  const ERROR_NOMBRE_EXISTE = -2;
  const OK = 1;

  # Datos Aplicación

  //Películas
  const ALIEN = "Alien";
  const BATMAN = "Batman";
  const TITANIC = "Titanic";

  //Butacas
  const NUM_BUTACAS_FILA = 10;
  const NUM_FILAS = 5;
  const REINICIAR_BUTACAS = "11111111111111111111111111111111111111111111111111";


?>