<?php 

  header('Location: views/insertar.php');

?>